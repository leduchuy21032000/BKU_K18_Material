clear all; close all; clc
%C�u 7
fprintf("B�i 7:")
x = -20:.1:20;
syms x y(x)
eqn = (1 + x^2)*diff(y,x) - 2*x*y == (1 + x^2)^exp(1);
y = dsolve(eqn,'y(0) = 1')
ezplot(y,[-20,20])
grid on
xlabel('x')
ylabel('y')