clear all; close all; clc
%C�u 2
fprintf("B�i 2:")
syms t
syms y
syms x
syms a
x(t) = log(t^3 + 2) - 1;
y(t) = sinh(t^2 - t - 2);

f = (diff(y(t)))/(diff(x(t)))
t = (solve(x(t) + 1 == 0, t,"Real",true))
subs(f,t)