clear all; close all; clc
%C�u 3
fprintf("B�i 3:")
syms x
%T�nh t�ch ph�n
int(1/((4-x)*(sqrt(1-x^2))),-1,1)
