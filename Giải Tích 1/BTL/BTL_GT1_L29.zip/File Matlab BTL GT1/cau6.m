clear all; close all; clc
%C�u 6
fprintf("B�i 6:")
syms y1
syms y2
syms x
y1 = exp(-x) + 1;
y2 = exp(-2*x) - 1;
n0 = solve(y1 == y2,x,"Real",true);
S = double(pi*int(abs(y1^2 - y2^2), n0, 0))