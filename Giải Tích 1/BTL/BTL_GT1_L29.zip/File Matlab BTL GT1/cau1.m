clear all; close all; clc
%C�u 1
fprintf("B�i 1:")
syms n
double(limit((((exp(n))^2 -1)/(n^2 + 1)),n,inf))
