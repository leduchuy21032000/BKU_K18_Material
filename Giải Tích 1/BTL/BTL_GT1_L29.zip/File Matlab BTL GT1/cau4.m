clear all; close all; clc
%C�u 4
fprintf("B�i 4:")
syms x
syms y1
syms y2
%Program to draw circles
t = linspace(0, 2*pi, 10000);
cir = @(r,ctr) [r*cos(t)+ctr(1); r*sin(t)+ctr(2)];                      % Circle Function
c1 = cir(1.0, [0; 0]);
c2 = cir(sqrt(2), [1; 0]);
in1 = find(inpolygon(c1(1,:), c1(2,:), c2(1,:), c2(2,:)));              % Circle #1 Points Inside Circle #2
in2 = find(inpolygon(c2(1,:), c2(2,:), c1(1,:), c1(2,:)));              % Circle #2 Points Inside Circle #1
[fillx,ix] = sort([c1(1,in1) c2(1,in2)]);                               % Sort Points
filly = [c1(2,in1) (c2(2,in2))];
filly = filly(ix);
figure(1)
plot(c1(1,:), c1(2,:),'yellow')
hold on
plot(c2(1,:), c2(2,:),'green')
fill([fillx fliplr(fillx)], [filly fliplr(filly)], 'g','EdgeColor','black')
%calcultate area between two circles
xcenter1 = 0;
ycenter1 = 0;
xcenter2 = 1;
ycenter2 = 0;
r1 = 1;
r2 = sqrt(2);
d2 = (xcenter2-xcenter1)^2+(ycenter2-ycenter1)^2;
d = sqrt(d2);
t = ((r1+r2)^2-d2)*(d2-(r2-r1)^2);
if t >= 0 % The circles overlap
   A = r1^2*acos((r1^2-r2^2+d2)/(2*d*r1)) ...
      +r2^2*acos((r2^2-r1^2+d2)/(2*d*r2)) ...
      -1/2*sqrt(t)
 elseif d > r1+r2  % The circles are disjoint
   A = 0
 else  % One circle is contained entirely within the other
   A = pi*min(r1,r2)^2
end




