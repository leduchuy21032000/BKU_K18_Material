clear all; close all; clc
%C�u 5
fprintf("B�i 5:")
syms y
x = 4-y^2
D = solve(x == 0, y, "Real", true)
double(int(2*pi*abs(x)*sqrt(1+diff(x)^2), D))
